# گزارش بررسی کامل و رفع باگ‌ها — ZEUS VPN

تاریخ بررسی: 2026-11-02 · شاخه: `bugfix/restore-and-fix`

## 🔴 یافتهٔ کلیدی: ۴ کامیت آخر، چهار فایل حیاتی را نابود کردند

بررسی تاریخچهٔ گیت نشان داد که آخرین کامیت‌ها هر کدام یک فایل را **جایگزین محتوای خراب** کرده‌اند
(الگوی ویرایشِ تخریبی، احتمالاً خروجی یک ابزار خودکار). نتیجه: **ریپو اصلاً کامپایل نمی‌شد** و CI در
مرحلهٔ Patch هم از کار می‌افتاد.

| کامیت | فایل قربانی | آسیب |
|---|---|---|
| `56a9052` «Update main.dart» | `lib/main.dart` | اپ اصلی (ZeusShell + صفحات + کنترلر) با یک بازنویسی مستقل جایگزین شد که **خطاهای کامپایل** داشت: `genWarpKeys()` تعریف‌نشده، فراخوانی `registerWarp(kp)` با آرگومان پوزیشنال روی تابعی که فقط named param دارد، و `warpLastError` ناموجود |
| `b0da0d9` «Implement secure connection handling in controller» | `lib/core/controller.dart` | کنترلر ۷۱۷ خطی با ۲۵ خط شبه‌کد جایگزین شد؛ داخل آن **متن فارسی به‌جای کد** نوشته شده بود (`isLoading.value = تمام شدن عملیات;`) و به `platform`، `isLoading`، `isConnected` ناموجود ارجاع می‌داد |
| `2ae92fb` «Implement Base64 decoding for subscription links» | `lib/pages/subs_page.dart` | صفحهٔ کامل ۲۵۷ خطی با یک اسنیپت ۱۹ خطی بدون `import 'dart:convert'` جایگزین شد |
| `fc490f0` «Patch AndroidManifest…» | `tools/patch_android.py` | اسکریپت پایتون CI با **XML خام** (تگ‌های `uses-permission`) جایگزین شد → `python3` روی XML سینتکس‌ارور می‌داد و بیلد در مرحلهٔ ۵ می‌مرد |

### راه‌حل اعمال‌شده
بازگردانی نسخه‌های سالم از تاریخچهٔ گیت (`commit^`) با **حفظ قصد** هر کامیت:
- دیکد Base64 اشتراک در `core/models.dart → parseSubscriptionBody()` موجود است (اسنیپت حذف‌شده بی‌دلیل بود)
- دسترسی‌های Manifest توسط اسکریپت پایتون واقعی و به شکل idempotent تزریق می‌شوند

---

## 🐞 سایر باگ‌های رفع‌شده

### 1. `tools/patch_signing.py` — IndentationError در CI
تمام خطوط فایل ۲ فاصله تورفتگی ماژول‌سطح داشتند → `python3` با
`IndentationError: unexpected indent` می‌مرد (مرحلهٔ Setup signing فقط وقتی Secret وجود داشت). بازنویسی تمیز شد.

### 2. `.github/workflows/build.yml` — هک `sed` خطرناک
`sed -i 's/^[[:space:]]*//' tools/patch_android.py` قبل از اجرا، **تمام تورفتگی‌های پایتون را می‌زد**
(فقط چون اسکریپت قدیمی تک‌خطی بود کار می‌کرد). حذف شد؛ اسکریپت‌ها دیگر به آن نیازی ندارند.

### 3. `Switch.activeThumbColor` — ناسازگاری با حداقل نسخهٔ اعلام‌شده
`pubspec.yaml` اجازهٔ Flutter ≥ 3.27 می‌دهد ولی `activeThumbColor` از نسخه‌های جدیدتر اضافه شده است →
در 3.27 **error کامپایل** (دو مورد: `logs_page.dart` و `settings_page.dart`). با `activeColor` جایگزین شد
که در همهٔ نسخه‌ها کار می‌کند.

### 4. `test/widget_test.dart` — همیشه fail می‌شد
- انتظار `find.text('ZEUS')` بود ولی اپ «ZEUS VPN» رندر می‌کند → `findNothing`
- `SharedPreferences.getInstance()` در تست mock نشده بود → `MissingPluginException`
- `pumpAndSettle` با انیمیشن‌های بی‌پایان پس‌زمینه هرگز settle نمی‌شود

### 5. کمبودهای CI
- مرحلهٔ `flutter test` وجود نداشت → اضافه شد
- APK `x86_64` بیلد می‌شد ولی در Release منتشر نمی‌شد → اضافه شد
- `analysis_options.yaml` و `.gitignore` نداشت → اضافه شد

### 6. موارد سبکی (info) از flutter_lints
۱۲ هشدار سبکی (const، آکولاد if) تمیز شد → `flutter analyze` اکنون **صفر**issue است.

---

## ✅ تأییدهای انجام‌شده

| بررسی | نتیجه |
|---|---|
| `flutter analyze` (با flutter_lints) | ✅ No issues found |
| `flutter test` | ✅ All tests passed |
| سازگاری API پلاگین `flutter_v2ray_client 3.5.0` با سورس پلاگین | ✅ (`V2RayStatus.upload/download`، `getServerDelay`، `getConnectedServerDelay`، `getLogs`، `startV2Ray`) |
| پورت inbound کانفیگ (10808/10809) با سرویس VPN اندروید پلاگین | ✅ (`V2rayConfig.java: LOCAL_SOCKS5_PORT=10808`) |
| سینتکس پایتون هر دو اسکریپت (`py_compile`) | ✅ |
| کامپایل تمیز Dart روی Flutter 3.27.4 stable | ✅ |

## 📦 خروجی‌ها

- شاخهٔ `bugfix/restore-and-fix` در ریپو (کامیت‌های مجزا برای هر اصلاح)
- `zeus_vpn_fixed.patch` — پچ کامل برای اعمال روی main
- `zeus_vpn_app_fixed.zip` — کل ریپوی اصلاح‌شده

> ⚠️ توصیهٔ امنیتی: `ci/keystore.b64` در ریپو فقط یک یادداشت متنی است، اما هرگز keystore واقعی را
> در ریپو کامیت نکنید؛ فقط از Secretهای GitHub استفاده کنید.
